NATURE GALLERY — 5 PAGE WEBSITE
================================

Pages:
- index.html (Home)
- gallery.html (Gallery)
- about.html (About)
- tips.html (Nature Tips)
- contact.html (Contact)

Assets:
- style.css
- images/mountains.svg
- images/forest.svg
- images/waterfall.svg
- images/lake.svg

Preview:
1. Extract this ZIP.
2. Open index.html in a browser.
3. Use the navigation bar to visit the other four pages.

Vercel deployment:
1. Visit https://vercel.com/drop and sign in.
2. Upload the extracted project folder or follow the current upload flow.
3. Deploy as a static site; no build command is needed.
4. Open the URL Vercel provides.

The contact form is a demo only; it does not send email or store messages.
